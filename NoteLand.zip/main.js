

let noteRootElement = document.querySelector('.noteList')
let folder = document.querySelector('.folder')
let textarea = document.querySelector('.createNoteList')
let headerValue =document.querySelector('#headerValue')
let noteListElement = document.querySelector('.noteListElement')
let notes = [];

textarea.style.display = 'none';

function renderElementToScreen(){
  if(localStorage.getItem('notes')){
    notes = JSON.parse(localStorage.getItem('notes'))
    notes.forEach(note => {
      renderNoteToList(note, note.uniqueId)
    });
  }
}


document.querySelector('#newButton').addEventListener('click', ()=>{
  console.log('a')
 if(folder.style.display !== 'none'){
  folder.style.display = 'none';
  textarea.style.display = 'block';
 }else{
  folder.style.display = 'block';
  textarea.style.display = 'none';
 }

})

document.querySelector('#createButton').addEventListener('click',()=>{
  let uniqueId = 'note' + Math.floor(Math.random()*1000)

  let note = {
    title : document.querySelector('#createNoteTitle').value,
    content : document.querySelector('#createNoteContent').value,
    // taskList : document.querySelector('#createNewTask').value

  }
  addLocalStrorage(note,uniqueId)
  renderNoteToList(note, uniqueId)  

})
 
function renderNoteToList(note,uniqueId){
  
  let noteDiv = document.createElement('div');
  noteDiv.classList.add('note',uniqueId)
  let noteTitle = document.createElement('h3');
  let noteContent = document.createElement('textarea');

  noteTitle.innerHTML = note.title;
  noteContent.innerHTML = note.content;
 
  noteDiv.appendChild(noteTitle)
  noteDiv.appendChild(noteContent)

  noteRootElement.appendChild(noteDiv)

  console.log(uniqueId)
  document.querySelector('#createNoteTitle').value =''
  document.querySelector('#createNoteContent').value = ''
  noteTorenderList()
  noteDiv.addEventListener('click',()=>{
    if(whiteArea === 'none'){
      whiteArea.style.display = 'block'
      headerDiv.style.display = 'block'
      document.querySelector('.folder').style.display = 'none'
      document.querySelector('.createNoteList').style.display = 'none'
    }else{
      whiteArea.style.display = 'block'
      document.querySelector('.createNoteList').style.display = 'none'
    }
  })
}

function noteTorenderList(note,uniqueId){ 
  let headerDiv = document.createElement('div')
  headerDiv.className = 'header'       
  let noteTitle = document.createElement('h3')
  let buttonsDiv = document.createElement('div')
  buttonsDiv.className = 'buttons';
  let newTask = document.createElement('button');
  newTask.id = 'newTaskButton'
  let deleteButton = document.createElement('button');
  deleteButton.id = 'deleteButton'

  newTask.innerHTML = 'NEW TASK';
  deleteButton.innerHTML = 'DELETE'
  // noteTitle.textCont =  note.title

  buttonsDiv.appendChild(newTask)
  buttonsDiv.appendChild(deleteButton)
  headerDiv.appendChild(noteTitle)
  headerDiv.appendChild(buttonsDiv)
  
  // headerDiv.style.display = 'none'
  headerValue.appendChild(headerDiv)

  let whiteArea = document.createElement('div');
  // whiteArea.textContent = note.content
  whiteArea.id = 'whiteArea';
  noteListElement.appendChild(whiteArea)

  whiteArea.style.display = 'none'
  // let inputTask = document.createElement('input');
  // whiteArea.appendChild(inputTask)
  // inputTask.style.display = 'none'
  // newTask.addEventListener('click', ()=>{
  //   inputTask.style.display = 'block'
  // })



  deleteButton.addEventListener('click',()=>{
    removeElementFromNoteList(uniqueId)
  })
  // addLocalStrorage(note,uniqueId)

  // renderNoteToList(note, uniqueId)  

}

function addLocalStrorage(note, uniqueId){
note = {...note,uniqueId}
  notes.push(note)     
localStorage.setItem('notes',JSON.stringify(notes))
}

function removeElementFromNoteList(id){
  console.log(id)
  document.querySelector('.' + id).remove();

  notes = JSON.parse(localStorage.getItem('notes'))

  let index = notes.findIndex(note=> note.uniqueId == id)

  notes.splice(index, 1)
  
  localStorage.setItem('notes', JSON.stringify(notes));
}
renderElementToScreen()